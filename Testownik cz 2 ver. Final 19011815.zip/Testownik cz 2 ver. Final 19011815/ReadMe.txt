EDIT ver. DDMMYYL HH:MM Opis zmiany (m�odsze roczniki proszone s� o aktualizowanie testownik�w tak jak poni�ej)

Semestr 2017/2018

EDIT ver. 1401182 11:38 (Poprawione pytanie nr 17)
EDIT ver. 1401183 15:10 (Poprawione pytanie nr 612)
EDIT ver. 1401184 15:15 (Poprawione pytanie nr 111)
EDIT ver. 1401185 15:34 Do bazy dodanych zosta�o 6 nowych pyta�, dzi�ki Tomaszowi. Nowe pytania znajdziecie na grupie oznaczonej ni�ej. Indeks pyta� w testowniku to 616-622. 
EDIT ver. 1401186 16:05 Do bazy dodane 1 pytanie
EDIT ver. 1501187 12:08 Do bazy dodanych zosta�o 6 pyta� oraz 7 poprawionych, dzi�ki Albertowi. Indeks nowych pyta� to 624-630.
EDIT ver. 1501188 13:02 (Poprawione pytanie nr 92) Dzi�ki Aleksandra.
EDIT ver. 1501189 13:13 (Poprawione pytanie nr 602) Dzi�ki Albert.
EDIT ver. 15011810 13:52 (Poprawione pytanie nr 163)
EDIT ver. 15011811 14:52 (Dodane pytanie 631 oraz 632 oraz wprowadzone zosta�y poprawki estetyczne)
EDIT ver. 15011812 12:54 (Dodane pytanie 634 trudne do odtworzenia, ale warto mie� je na uwadze)
EDIT ver. 19011813 11:58 (Poprawione pytanie nr 111,609 oraz 602)
EDIT ver. 19011814 19:03 (Usuni�te pytanie 289 - dubel z 609)
EDIT ver. 19011815 19:21 (Usuni�to bia�e t�o z obrazk�w)

Uwaga od autora:

Testownik NIGDY nie gwarantuje zdobycia minimalnej liczby punkt�w na te�cie i powinien by� stosowane WY��CZNIE do 
powt�rki materia�u, kt�ry mo�na znale�� na slajdach na stronie katedry ZTS. Mimo bardzo dobrych wynik�w w semestrze
zimowym 2017/2018, w semestrze 2018/2019 du�o pyta� mo�e si� zmieni�, tym samym testownik mo�e sta� si� nieaktualny.

Chcia�bym podzi�kowa� wszystkim, kt�rzy sp�dzili godziny wieczorami, pomagaj�c mi poprawia� pytania i aktualizowa� star�
baz� pyta�. MI�DZY INNYMI s� to:

Albert, Piotr, Marcin, Janek, Piotr, Bartolomeo, Marcin, Juliusz, Aleksandra, Bartek, Bartosz, Piotrek, Karolina,
Marta, Marta, Kasia, Kamil, Jacek, Krystian, Marek, Konrad, Dawid, Krzysztof i wiele innych os�b..

Baz� aktualizowa�: Mati :) (a cz�� Tomek)